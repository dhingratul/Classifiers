% ---------------------------------------------------------------------- %
% OCR: Main File
% Author: Atul Dhingra
% dhingra[dot]atul92[at]gmail.com
% ---------------------------------------------------------------------- %
clear all;
close all;
clc;
load Feature_Test;
load Feature_Validation
load labels;
perceptron()